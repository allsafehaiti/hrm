<?php

namespace App\Model\DossierEmploye;

use Illuminate\Database\Eloquent\Model;

class EmployeSkill extends Model
{
    protected $table='employe_skills';
    protected $guarded=[];
    public $timestamps=false;
}
