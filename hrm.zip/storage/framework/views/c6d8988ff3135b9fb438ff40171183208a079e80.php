<?php $getProfession = app('App\getProfession'); ?>
<meta name="viewport" content="width=device-width, initial-scale=1">
<div class='container' style="width:95%;">
        <table id='list' class=' display' style='display:none;'>
                <thead>
                    <tr>
                        <th>Nom</th>
                        <th>Prenom</th>
                        <th>Profession</th>
                        <th>Email</th>
                        <th>Cin</th>
                        <th>Date Creation</th>
                        <th>Date Modification</th>
                    </tr>
                </thead>

                <tbody>
                    <?php $__currentLoopData = $listeDossierEmploye; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $DossierEmploye): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr id='rowC' style='cursor:pointer;'>
                          <input type='hidden' value=<?php echo e($DossierEmploye->id); ?>>
                    <td> <?php echo e($DossierEmploye->Nom); ?></td>
                    <td> <?php echo e($DossierEmploye->Prenom); ?></td>
                    <td> <?php echo e($getProfession->getProfession($DossierEmploye->Profession)); ?></td>
                      <td><?php echo e($DossierEmploye->Email); ?></td>
                    <td> <?php echo e($DossierEmploye->Nif); ?></td>
                    <td><?php echo e($DossierEmploye->created_at); ?></td>
                    <td><?php echo e($DossierEmploye->updated_at); ?></td>
                  </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
            </table>
</div>




<link rel="stylesheet" type="text/css" href="css/jquery.datatables.css">
<script type="text/javascript" charset="utf8" src="js/jquery.datatables.js"></script>
<script type="text/javascript" charset="utf8" src="js/dataTables.bootstrap.min.js"></script>

<script>
    $(document).ready(function()
    {
        $('#list').DataTable
        (
            {


                "language":
                {
                    "lengthMenu": "Montre _MENU_ resultats par page",
                    "zeroRecords": "Aucune information - desole",
                    "info": "Montre _PAGE_ de _PAGES_",
                    "infoEmpty": "Aucun resultat trouve",
                    "infoFiltered": "(filtre de _MAX_ total resultats)",
                    "search": "Recherche",
                    "paginate":
                    {
                    "previous":"Precedent",
                    "next":"Prochain"
                    }


                }

            }

        );
            $('#list').fadeIn(400);



    });
    $('tr').click(function(){

let id=$(this).find('input').val();
$('#page').load('dossierEmploye/'+id);

});
</script>
<?php /**PATH C:\wamp64\www\hrm\resources\views/listeDossierEmploye.blade.php ENDPATH**/ ?>